<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
   "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="language" content="english"> 
<meta http-equiv="Content-Style-Type" content="text/css">

<title>my little button</title>

<link rel="stylesheet" type="text/css" href="files/mybutton-style.css">

</head>
<body>

<form action="files/count.php" method="post">
<div>
 <input name="stuff" type="text" value="<?php include 'files/input-content.txt'?>">
 <input id="mybutton" name="mybutton" type="submit" value="<?php include 'files/count-total.txt'?>">
</div>
</form>

<div id="input-test">The input value="<?php include 'files/input-content.txt'?>"</div>

</body>
</html>
