<?php
   $clicks=('count-total.txt');
   $num=file($clicks);
   $num[0]++;
   $fp=fopen($clicks,'w');
   fputs($fp,"$num[0]");
   fclose($fp);

   header('Location:../button-page.php');



   $foo=$_POST['stuff'];
   $inputs=('input-content.txt');
   $blah=file($inputs);
   $blah[0]=$foo;
   $fpo=fopen($inputs,'w');
   fputs($fpo,"$blah[0]");
   fclose($fpo);
?>